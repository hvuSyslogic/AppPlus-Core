namespace HisPlus.Domain
{
    public partial interface IHisDbContext : System.IDisposable
    {
        System.Data.Entity.DbSet<BsItem> BsItems { get; set; }
        System.Data.Entity.DbSet<BsLocation> BsLocations { get; set; }
        System.Data.Entity.DbSet<BsPatient> BsPatients { get; set; }
        System.Data.Entity.DbSet<BsPatientYbIll> BsPatientYbIlls { get; set; }

        int SaveChanges();
        System.Threading.Tasks.Task<int> SaveChangesAsync();
        System.Threading.Tasks.Task<int> SaveChangesAsync(System.Threading.CancellationToken cancellationToken);
    }

}
